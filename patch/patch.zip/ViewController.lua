waxClass{"ViewController",UIViewController}
-- IBOutlet "label"
-- function viewDidLoad(self)

-- print(viewDidLoad)

-- end

function viewDidLoad(self)

print(112)
self.super:viewDidLoad(self)
	self:label():setColor(UIColor:greenColor())
	self:label():setText("我还有俩只视野,从来也不插0_0")
print(113)

end

-- function viewDidLoad(self)
-- 	self.super:viewDidLoad(self)
-- 	self.label:setColor(UIColor:greenColor())
-- 	self.label:setText("我还有俩只视野,从来也不插0_0")
-- end

-- function viewDidLoad(self)

-- print(112)
-- self.super:viewDidLoad(self)
-- 	local label = UILabel:initWithFrame(CGRect(0, 100, 320, 35))  
--     label:setFont(UIFont:boldSystemFontOfSize(30))  
--     label:setColor(UIColor:whiteColor())  
--     label:setBackgroundColor(UIColor:colorWithRed_green_blue_alpha(0.545, 0.3, 1, 1))  
--     label:setText("前方高能：")  
--     label:setTextAlignment(UITextAlignmentCenter)  
--     self:view():addSubview(label)  
-- print(113)

-- end

